#!/bin/bash
# script that slow prints a process
echo -e "** \c"
echo -e "$1\c"
echo -e ".\c"
sleep 1
echo -e ".\c"
sleep 1
echo -e ".\c"
sleep 1
echo "done"
sleep 1