#!/bin/bash
#this script creates the necessary files for the website

#store parameter
ROOT=$1
TYPE=$2

#create css file
CSS="$ROOT/css/app.css"

#add logo
cp logo.png $ROOT/assets/images/

#create index file
INDEX="$ROOT/index.html"
#add head
HEAD="<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n\t<meta charset=\"UTF-8\">\n\t<title>$ROOT</title>\n\t<link rel=\"stylesheet\" href=\"css/app.css\">\n</head>"

#name of each section/page
HEADERS_NAMES=("Home" "Other" "About" "Contact")
#add body and nav
BODY_TOP="<body>\n\t<!-- Navigation bar -->"
BODY_TOP="$BODY_TOP\n\t<nav>\n\t\t<!-- Logo -->\n\t\t<img id=\"logo\" src=\"assets/images/logo.png\" alt=\"logo\">"
BODY_TOP="$BODY_TOP\n\t\t<!-- Navigation Links -->\n"
for ((x=0; x<${#HEADERS_NAMES[@]}; x++)); do
  if [ "$TYPE" == "SPA" ]; then
    BODY_TOP="$BODY_TOP\t\t<a href=\"#${HEADERS_NAMES[$x],,}\">${HEADERS_NAMES[$x]}</a>\n"
  else
    if [ "$x" -eq 0 ]; then
      BODY_TOP="$BODY_TOP\t\t<a href=\"./index.html\">${HEADERS_NAMES[$x]}</a>\n"
    else
      BODY_TOP="$BODY_TOP\t\t<a href=\"./${HEADERS_NAMES[$x],,}.html\">${HEADERS_NAMES[$x]}</a>\n"
    fi
  fi  
done
BODY_TOP="$BODY_TOP\t</nav>"

#add css for body and nav
CSS_INFO="* {\n\tbox-sizing: border-box;\n\tmargin: 0;\n\tpadding: 0;\n\tscroll-behavior: smooth;\n}\n"
CSS_INFO="$CSS_INFO/* Logo */\n#logo {\n\twidth: 150px;\n\tposition: relative;\n\tfloat: left;\n\tpadding: 0 auto;\n}\n"
CSS_INFO="$CSS_INFO/* CSS styles for navigation bar */\nnav {\n\tbackground-color: #333;\n\toverflow: hidden;\n}\n"
CSS_INFO="$CSS_INFO nav a {\n\tfloat: left;\n\tcolor: #f2f2f2;\n\ttext-align: center;\n\tpadding: 14px 16px;\n\ttext-decoration: none;\n\tfont-size: 18px;\n}\n"
CSS_INFO="$CSS_INFO nav a:hover {\n\tbackground-color: #ddd;\n\tcolor: black;\n}\n"

#footer
FOOT="<!-- Footer -->\n\t<footer>\n\t\t<p>$ROOT - Copyright © $(date +%Y)</p>\n\t</footer>\n</body>\n</html>"

#add css for footer
CSS_INFO="$CSS_INFO/* CSS styles for the footer */\nfooter {\n\tbackground-color: #333;\n\tcolor: white;\n\tpadding: 10px;\n"
if [ "$TYPE" != "SPA" ]; then
  CSS_INFO="$CSS_INFO\tposition: absolute;\n"
fi
CSS_INFO="$CSS_INFO\ttext-align: center;\n\tbottom: 0;\n\twidth: 100%;\n}\n"

#contact form
CONTACT_FORM="\t\t<div id=\"form_container\">\n"
CONTACT_FORM="$CONTACT_FORM\t\t\t<form action=\"#\" method=\"post\">\n\t\t\t\t<label for=\"name\">Name:</label>\n"
CONTACT_FORM="$CONTACT_FORM\t\t\t\t<input type=\"text\" id=\"name\" name=\"name\" required>\n"
CONTACT_FORM="$CONTACT_FORM\t\t\t\t<label for=\"email\">Email:</label>\n"
CONTACT_FORM="$CONTACT_FORM\t\t\t\t<input type=\"email\" id=\"email\" name=\"email\" required>\n"
CONTACT_FORM="$CONTACT_FORM\t\t\t\t<label for=\"message\">Message:</label>\n"
CONTACT_FORM="$CONTACT_FORM\t\t\t\t<textarea id=\"message\" name=\"message\" required></textarea>\n"
CONTACT_FORM="$CONTACT_FORM\t\t\t\t<button type=\"submit\">Send</button>\n\t\t\t</form>\n\t\t</div>\n"

#add css for contact form
CSS_INFO="$CSS_INFO/* CSS styles for the contact form */\n#form_container {\n\tmax-width: 600px;\n"
CSS_INFO="$CSS_INFO\tmargin: auto;\n\tpadding: 20px;\n\ttext-align: center;\n\tbackground-color: #f7f7f7;\n}\n"
CSS_INFO="$CSS_INFO form label {\n\tdisplay: block;\n\tmargin-bottom: 10px;\n\tfont-weight: bold;\n}\n"
CSS_INFO="$CSS_INFO form input,\nform textarea {\n\twidth: 100%;\n\tpadding: 10px;\n\tmargin-bottom: 20px;\n"
CSS_INFO="$CSS_INFO\tborder-radius: 5px;\n\tborder: 1px solid #ccc;\n\tfont-size: 16px;\n}\n"
CSS_INFO="$CSS_INFO form textarea {\n\theight: 150px;\n}\n"
CSS_INFO="$CSS_INFO form button {\n\tdisplay: block;\n\tmargin: 0 auto;\n\tpadding: 10px 20px;\n"
CSS_INFO="$CSS_INFO\tborder-radius: 5px;\n\tborder: none;\n\tbackground-color: #ff0000;\n"
CSS_INFO="$CSS_INFO\tcolor: #fff;\n\tfont-size: 16px;\n\tcursor: pointer;\n}\n"
CSS_INFO="$CSS_INFO form button:hover {\n\tbackground-color: #d90000;\n}\n"



#Single Page Website
if [ "$TYPE" == "SPA" ]; then
#add sections
  SECTION=""
  for ((x=0; x<${#HEADERS_NAMES[@]}; x++)); do
    SECTION="$SECTION\t<!-- ${HEADERS_NAMES[$x]} section -->\n"
    SECTION="$SECTION\t<section id=\"${HEADERS_NAMES[$x],,}\">\n"
    if [ "$x" -eq 0 ]; then
      SECTION="$SECTION\t\t<h1>Welcome to my website</h1>\n"
    else
      SECTION="$SECTION\t\t<h1>${HEADERS_NAMES[$x]} Section</h1>\n"
    fi
    SECTION="$SECTION\t\t<p>This is the ${HEADERS_NAMES[$x],,} section.</p>\n"
    if [ "${HEADERS_NAMES[$x],,}" == "contact" ]; then
      SECTION="$SECTION $CONTACT_FORM"
    fi
    SECTION="$SECTION\t</section>\n"
  done
  #css for section
  CSS_INFO="$CSS_INFO/* CSS styles for the main sections */\nh1 {\n\tmargin-bottom: 20px;\n}\n"
  CSS_INFO="$CSS_INFO section {\n\tpadding: 50px;\n\ttext-align: center;\n\theight: 800px;\n}\n"

  #create index file for SPA
  echo -e "$HEAD" >> $INDEX
  echo -e "$BODY_TOP" >> $INDEX
  echo -e "$SECTION" >> $INDEX
  echo -e "$FOOT" >> $INDEX
else
  #Multipage Website
  PAGE=""
  PAGE_INFO=""
  for ((x=0; x<${#HEADERS_NAMES[@]}; x++)); do
    #create page
    if [ "$x" -eq 0 ]; then
      PAGE="$INDEX"
      PAGE_INFO="<h1>Welcome to my website</h1>\n"
    else
      PAGE="$ROOT/${HEADERS_NAMES[$x],,}.html"
      PAGE_INFO="<h1>${HEADERS_NAMES[$x]}</h1>\n"
    fi
    #add contact form
    if [ "${HEADERS_NAMES[$x],,}" == "contact" ]; then
      PAGE_INFO="$PAGE_INFO $CONTACT_FORM"
    fi
    #add content to page
    echo -e "$HEAD" >> $PAGE
    echo -e "$BODY_TOP" >> $PAGE
    echo -e "$PAGE_INFO" >> $PAGE
    echo -e "$FOOT" >> $PAGE
  
  done  
fi 
#create css file
echo -e "$CSS_INFO" >> $CSS

# Print success message
./slowPrint.sh "$ROOT: Creating Files"
echo "**"
echo "** Your website files have been stored at the following address below."
echo "** Project: $ROOT"
echo "** Website Type: $TYPE"
echo -e "** Location: \c"
readlink -f $ROOT

