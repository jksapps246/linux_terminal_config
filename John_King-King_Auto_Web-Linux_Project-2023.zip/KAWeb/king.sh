#!/bin/bash
#script to create a website template based on the user's parameters
clear
echo "********************************************"
echo "******King's Auto Web Page Project - *******"
#store parameters
if [ -z "$1" ]; then
  #prompt for missing parameters
  #project name
  echo -e "** \c"
  read -p "Enter Project Name: " PROJECT
else
PROJECT=$1
fi

if [ -z "$2" ]; then
  #prompt for missing parameters
  #type of website
  echo -e "** \c"
  read -p "Single Page Website? (y/n): " TYPE
else 
TYPE=$2 
fi
#set type if website to create
if [ "$TYPE" == "y" ]; then
  #Single Page Application
  TYPE="SPA"
else
  #Multi Page Application
  TYPE="MultiPage"
fi
#create the folder structure for the website
if test -d $PROJECT; then
  OW="n"
  #prompt to overwrite the existing folders
  echo -e "** \c"
  read -p "Overwrite Existing Project? (y/n): " OW
  if [ "$OW" == "y" ]; then
    #delete folder
    rm -r $PROJECT
    #create folders
    ./getFolders.sh $PROJECT
    ./getFiles.sh $PROJECT $TYPE
  else
    echo "** $PROJECT not created"
  fi
else
  #create folders
  ./getFolders.sh $PROJECT
  ./getFiles.sh $PROJECT $TYPE  
fi


