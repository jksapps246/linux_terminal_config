#!/bin/bash
# script that creates a folder structure for the website

# Creates a variable
PROJECT=$1

# Create a directory
mkdir $PROJECT

# Create subfolders for css, assets, and javascripts
mkdir -p $PROJECT/css
mkdir -p $PROJECT/assets 
mkdir -p $PROJECT/assets/images
mkdir -p $PROJECT/js

# Print success message
./slowPrint.sh "$PROJECT: Creating Folders"
